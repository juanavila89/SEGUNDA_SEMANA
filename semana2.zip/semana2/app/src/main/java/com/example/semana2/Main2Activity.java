package com.example.semana2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private TextView textNombre, textTelefono, textEmail, textDesContacto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Bundle parametros = getIntent().getExtras();

        textNombre= (TextView) findViewById(R.id.textNombre);
        textTelefono = (TextView) findViewById(R.id.textTelefono);
        textEmail = (TextView) findViewById(R.id.textEmail);
        textDesContacto = (TextView) findViewById(R.id.textDesContacto);


        String Nombre = getIntent().getStringExtra("Nombre");
        String Telefono = getIntent().getStringExtra("Telefono");
        String Email = getIntent().getStringExtra("Email");
        String Contacto = getIntent().getStringExtra("Contacto");

        textNombre.setText(Nombre);
        textTelefono.setText(Telefono);
        textEmail.setText(Email);
        textDesContacto.setText(Contacto);


    }
}
